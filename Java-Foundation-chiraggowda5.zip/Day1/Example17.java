import java.util.Scanner;

class Example17 {
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);

    int pm = 0, im = 0, em = 0, total = 0;
    char grade = 'N';

    System.out.println("Enter Project marks : ");
    pm = s.nextInt();
    System.out.println("Enter Internal marks : ");
    im = s.nextInt();
    System.out.println("Enter External marks : ");
    em = s.nextInt();

    if (pm < 50 || im < 50 || em < 50) {
      if (pm < 50) {
        System.out.println("You failed in Project " + pm + " marks");
      }
      if (im < 50) {
        System.out.println("You failed in Internals " + im + " marks");
      }
      if (em < 50) {
        System.out.println("You failed in External " + em + " marks");
      }
    } else {
      int projectGrade = 0, internalGrade = 0, externalGrade = 0;

      projectGrade = (70 * pm) / 100;
      internalGrade = (10 * im) / 100;
      externalGrade = (20 * em) / 100;

      total = projectGrade + internalGrade + externalGrade;

      if (total >= 90) {
        grade = 'A';
      } else if (total >= 70 && total < 90) {
        grade = 'B';
      } else {
        grade = 'C';
      }
      System.out.println("You grade is " + grade);
    }
  }
}