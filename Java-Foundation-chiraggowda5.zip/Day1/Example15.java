import java.util.Scanner;

class Example15 {

  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);

    int gs = 0, bs = 0, hra = 0, da = 0;

    System.out.println("Enter the basic salary");
    bs = s.nextInt();
    if (bs <= 10000) {
      hra = (67 * bs) / 100;
      da = (78 * bs) / 100;
    } else if (bs > 10000 && bs <= 20000) {
      hra = (70 * bs) / 100;
      da = (80 * bs) / 100;
    } else {
      hra = (73 * bs) / 100;
      da = (87 * bs) / 100;
    }
    gs = bs + hra + da;
    System.out.println("The hra is :" + hra);
    System.out.println("The da is :" + da);
    System.out.println("The gross salary is :" + gs);

  }
}