import java.util.Scanner;

class Example12 {
  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);
    int num;
    System.out.println("enter the number");
    num = s.nextInt();
    if (num == 1) {
      System.out.println("Sunday");
    } else if (num == 2) {
      System.out.println("Monady");
    } else if (num == 3) {
      System.out.println("Tuesday");
    } else if (num == 4) {
      System.out.println("Wednesday");
    } else if (num == 5) {
      System.out.println("Thursady");
    } else if (num == 6) {
      System.out.println("Friday");
    } else {
      System.out.println("Saturday");
    }

  }

}