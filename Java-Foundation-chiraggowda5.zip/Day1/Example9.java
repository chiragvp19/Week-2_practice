import java.util.Scanner;

class Example9 {
  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);
    int num;
    System.out.println("enter the number");
    num = s.nextInt();
    if (num >= 0) {
      System.out.println("positive number");
    } else {
      System.out.println("negative number");
    }

  }

}