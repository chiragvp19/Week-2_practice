class Example5 {
  public static void main(String args[]) {
 
   String str="bitLabs";
    int a=100;
    int b=50;
 
    System.out.println(str+a+b);
    System.out.println(a+b+str);  
    System.out.println(b+str+a); 
    
 
  }
}