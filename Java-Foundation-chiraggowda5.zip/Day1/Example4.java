class Example4 {

  public static void main(String args[]) {
    byte a = 1;
    short b = 2;
    long c = 345;
    int d = 400;
    boolean e = a > b;
    double f = 63.25;
    float g = 7.14f;
    char hh = 'h';
    string str = "Chirag";

    System.out.println("Byte value is : " + a);
    System.out.println("short value is : " + b);
    System.out.println("long value is : " + c);
    System.out.println("int value is : " + d);
    System.out.println("Boolean value is : " + e);
    System.out.println("double value is : " + f);
    System.out.println("float value is : " + g);
    System.out.println("Char value is : " + hh);
    System.out.println("String  is : " + str);

  }
}