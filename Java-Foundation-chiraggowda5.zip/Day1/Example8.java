import java.util.Scanner;

class Example8 {

  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);

    int gs = 0, bs = 0, hra = 0, da = 0;

    System.out.println("Enter the basic salary");
    bs = s.nextInt();
    hra = (89 * bs) / 100;
    da = (90 * bs) / 100;
    gs = bs + hra + da;
    System.out.println("The hra is :" + hra);
    System.out.println("The da is :" + da);
    System.out.println("The gross salary is :" + gs);

  }
}