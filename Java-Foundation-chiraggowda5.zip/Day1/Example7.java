import java.util.Scanner;

class Example7 {
  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);

    int first_bill = 0, second_bill = 0, third_bill = 0;
    int total = 0, salary = 0, percentage = 0;

    System.out.println("Enter 3 shopping bills");
    first_bill = s.nextInt();
    second_bill = s.nextInt();
    third_bill = s.nextInt();
    System.out.println("Enter the total salary");
    salary = s.nextInt();

    total = first_bill + second_bill + third_bill;
    percentage = (total*100)/salary;

    System.out.println(" Total bill is : " + total);
    System.out.println("Percentage of salary is : " + percentage);

  }
}