import java.util.Scanner;

class Example10 {
  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);
    int num;
    System.out.println("enter the number");
    num = s.nextInt();
    if (num % 2 == 0) {
      System.out.println("even number");
    } else {
      System.out.println("odd number");
    }

  }

}