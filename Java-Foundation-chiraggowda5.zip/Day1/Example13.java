import java.util.Scanner;

class Example13 {
  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);
    int amt, fiveh = 0, twoh = 0, oneh = 0;
    System.out.println("enter the Amount");
    amt = s.nextInt();
    if (amt % 100 != 0 && amt <= 0) {
      System.out.println("Invalid Amount");
    } else if (amt >= 500) {
      fiveh = amt / 500;
      amt = amt % 500;
    } else if (amt >= 200 && amt < 500) {
      twoh = amt / 200;
      amt = amt % 200;
    } else {
      oneh = amt / 100;
      amt = amt % 100;
    }
    System.out.println("No.Of Notes for given amount is ");
    System.out.println("Five Hundreds: " + fiveh);
    System.out.println("Two Hundreds: " + twoh);
    System.out.println("Hundreds: " + oneh);

  }

}