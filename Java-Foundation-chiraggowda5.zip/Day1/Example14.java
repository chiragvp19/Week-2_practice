import java.util.Scanner;

class Example14 {
  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);
    double units, bill = 0;
    System.out.println("enter the units");
    units = s.nextInt();
    if (units <= 50) {
      bill = 0.50 * units;
    } else if (units > 50 && units <= 150) {
      bill = units * 1.23;
    } else if (units > 150 && units <= 250) {
      bill = units * 1.90;
    } else {
      bill = units * 2.34;
    }
    System.out.println("Bill  amount is " + bill);

  }

}