import java.util.Scanner;

class Example16 {
  public static void main(String args[]) {

    Scanner s = new Scanner(System.in);
    int year;
    System.out.println("enter the year");
    year = s.nextInt();
    if (year % 4 == 0) {
      System.out.println("Leap Year");
    } else {
      System.out.println("Not a Leap Year");
    }

  }

}